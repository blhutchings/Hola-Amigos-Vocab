# Hola-Amigos-Vocab

Note: No mobile support, I don't know how to do that. :)

A webpage with all the vocabulary from chapter 0 to chapter 12 of the book "¡Hola, amigos! Fourth Canadian Edition"

Features:
  - Flash cards of all selected chapters are in the deck
  - Random order of vocabulary
  - Options to select if the front card should be spanish, english, or is random.
