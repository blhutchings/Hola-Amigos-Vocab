const flash_card_det2 = [
	
{
"term": "a",
"definition":"(prep.) at (with time of day); to",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/a.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 1 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "¿A qué hora…?",
"definition":"(exp.) (At) What time...?",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/a_qu_horagca.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 2 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "a veces",
"definition":"(exp.) sometimes",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/a_veces.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 3 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "abril",
"definition":"(sust. m.) April",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/abril.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 4 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "aburrido(-a)",
"definition":"(adj.) boring",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/aburrido_a.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 5 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "administración",
"definition":"(sust. f.) administration",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/administracion.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 6 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "administración de empresas",
"definition":"(sust. f.) business administration",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/administracion_de_empresas.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 7 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "agosto",
"definition":"(sust. m.) August",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/agosto.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 8 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "agua",
"definition":"(sust. f.) water",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/agua.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 9 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "agua con hielo",
"definition":"(sust. f.) water with ice",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/agua_con_hielo.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 10 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "agua mineral",
"definition":"(sust. f.) mineral water",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/agua_mineral.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 11 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "amigo(-a)",
"definition":"(sust. m./f.) friend",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/amigo_a.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 12 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "mejor amigo(-a)",
"definition":"(exp.) best friend",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/mejor_amigo_a.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 13 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "año",
"definition":"(sust. m.) year",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/ano.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 14 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "antropología",
"definition":"(sust. f.) anthropology",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/antropologia.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 15 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "arte",
"definition":"(sust. m.) art",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/arte.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 16 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "asignatura",
"definition":"(sust. f.) course, subject",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/asignatura.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 17 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "aula",
"definition":"(sust. f.) classroom",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/aula.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 18 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "bailar",
"definition":"(v.) to dance",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/bailar.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 19 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "bebida",
"definition":"(sust. f.) beverage",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/bebida.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 20 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "biología",
"definition":"(sust. f.) biology",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/biologia.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 21 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "botella",
"definition":"(sust. f.) a bottle",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/botella.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 22 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "buen, bueno(-a)",
"definition":"(adj.) good",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/buen_bueno_a.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 23 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "café",
"definition":"(sust. m.) coffee",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/cafe.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 24 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "café con leche",
"definition":"(sust. m.) coffee with milk",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/cafe_con_leche.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 25 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "cenar",
"definition":"(v.) to dine",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/cenar.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 26 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "cerveza",
"definition":"(sust. f.) beer",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/cerveza.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 27 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "chocolate caliente",
"definition":"(sust. m.) hot chocolate",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/chocolate_caliente.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 28 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "cien, ciento",
"definition":"(sust. m.) one hundred",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/cien_ciento.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 29 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "ciencias políticas",
"definition":"(sust. f. pl.) political science",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/ciencias_politicas.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 30 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "cincuenta",
"definition":"(sust. m.) fifty",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/cincuenta.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 31 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "comprar",
"definition":"(v.) to buy",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/comprar.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 32 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "contabilidad",
"definition":"(sust. f.) accounting",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/contabilidad.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 33 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "conversar",
"definition":"(v.) to talk, to converse",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/conversar.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 34 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "¿Cuándo?",
"definition":"(adv.) When?",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/cuando_.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 35 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "¿Cuántos(-as)?",
"definition":"(exp.) How many?",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/cuantos_as.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 36 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "de",
"definition":"(prep.) of, about, in",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/de.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 37 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "desear",
"definition":"(v.) to wish, to want",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/desear.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 38 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "diciembre",
"definition":"(sust. m.) December",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/diciembre.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 39 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "dinero",
"definition":"(sust. m.) money",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/dinero.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 40 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "dólar",
"definition":"(sust. m.) dollar",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/dolar.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 41 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "domingo",
"definition":"(sust. m.) Sunday",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/domingo.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 42 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "doscientos",
"definition":"(sust. m.) two hundred",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/doscientos.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 43 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "educación física",
"definition":"(sust. f.) physical education",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/educacion_fisica.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 44 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "enero",
"definition":"(sust. m.) January",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/enero.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 45 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "enseñar",
"definition":"(v.) to teach",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/ensenar.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 46 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "entonces",
"definition":"(adv.) then",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/entonces.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 47 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "escuchar",
"definition":"(v.) to listen to",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/escuchar.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 48 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "estación",
"definition":"(sust. f.) season",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/estacion.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 49 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "estudiar",
"definition":"(v.) to study",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/estudiar.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 50 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "febrero",
"definition":"(sust. m.) February",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/febrero.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 51 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "física",
"definition":"(sust. f.) physics",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/fisica.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 52 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "geografía",
"definition":"(sust. f.) geography",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/geografia.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 53 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "geología",
"definition":"(sust. f.) geology",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/geologia.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 54 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "hablar",
"definition":"(v.) to speak",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/hablar.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 55 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "té helado",
"definition":"(sust. m.) iced tea",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/te_helado.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 56 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "hielo",
"definition":"(sust. m.) ice",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/hielo.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 57 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "hispanocanadiense",
"definition":"(sust. m./f.) Hispanic-Canadian",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/hispanocanadiense.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 58 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "historia",
"definition":"(sust. f.) history",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/historia.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 59 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "hora",
"definition":"(sust. f.) time",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/hora.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 60 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "horario de clases",
"definition":"(sust. m.) class schedule",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/horario_de_clases.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 61 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "hoy",
"definition":"(adv.) today",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/hoy.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 62 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "idea",
"definition":"(sust. f.) idea",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/idea.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 63 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "importante",
"definition":"(adj.) important",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/importante.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 64 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "imposible",
"definition":"(adj.) impossible",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/imposible.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 65 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "informática",
"definition":"(sust. f.) computer science",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/informatica.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 66 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "inglés",
"definition":"(sust. m.) English (language)",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/ingles.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 67 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "internacional",
"definition":"(adj.) international",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/internacional.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 68 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "invierno",
"definition":"(sust. m.) winter",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/invierno.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 69 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "no vamos",
"definition":"(exp.) we are not going",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/no_vamos.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 70 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "jueves",
"definition":"(sust. m.) Thursday",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/jueves.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 71 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "jugo",
"definition":"(sust. m.) juice",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/jugo.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 72 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "jugo de manzana",
"definition":"(sust. m.) apple juice",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/jugo_de_manzana.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 73 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "jugo de naranja",
"definition":"(sust. m.) orange juice",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/jugo_de_naranja.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 74 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "jugo de tomate",
"definition":"(sust. m.) tomato juice",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/jugo_de_tomate.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 75 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "jugo de toronja",
"definition":"(sust. m.) grapefruit juice",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/jugo_de_toronja.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 76 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "jugo de uvas",
"definition":"(sust. m.) grape juice",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/jugo_de_uvas.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 77 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "julio",
"definition":"(sust. m.) July",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/julio.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 78 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "junio",
"definition":"(sust. m.) June",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/junio.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 79 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "juntos(-as)",
"definition":"(adj.) together",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/juntos_as.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 80 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "leche",
"definition":"(sust. f.) milk",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/leche.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 81 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "literatura",
"definition":"(sust. f.) literature",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/literatura.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 82 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "los (las) dos",
"definition":"(adj. inv./pron.) both",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/los_las_dos.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 83 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "lunes",
"definition":"(sust. m.) Monday",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/lunes.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 84 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "mañana",
"definition":"(adv.) tomorrow",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/manana.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 85 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "manzana",
"definition":"(sust. f.) apple",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/manzana.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 86 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "martes",
"definition":"(sust. m.) Tuesday",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/martes.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 87 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "marzo",
"definition":"(sust. m.) March",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/marzo.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 88 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "matemáticas",
"definition":"(sust. f. pl.) mathematics",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/matematicas.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 89 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "mayo",
"definition":"(sust. m.) May",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/mayo.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 90 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "mediodía",
"definition":"(sust. m.) noon",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/mediodia.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 91 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "mes",
"definition":"(sust. m.) month",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/mes.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 92 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "miércoles",
"definition":"(sust. m.) Wednesday",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/miercoles.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 93 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "música",
"definition":"(sust. f.) music",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/musica.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 94 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "naranja",
"definition":"(sust. f.) orange (fruit)",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/naranja.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 95 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "necesitar",
"definition":"(v.) to need",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/necesitar.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 96 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "noche",
"definition":"(sust. f.) night",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/noche.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 97 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "por la noche",
"definition":"(exp.) at night",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/por_la_noche.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 98 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "noventa",
"definition":"(sust. m.) ninety",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/noventa.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 99 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "noviembre",
"definition":"(sust. m.) November",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/noviembre.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 100 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "nuestro(-a)(-s)",
"definition":"(adj.) our",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/nuestro_a_s.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 101 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "nuevo(-a)",
"definition":"(adj.) new",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/nuevo_a.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 102 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "ochenta",
"definition":"(sust. m.) eighty",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/ochenta.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 103 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "octubre",
"definition":"(sust. m.) October",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/octubre.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 104 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "oﬁcina",
"definition":"(sust. f.) ofﬁce",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/on_ucina.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 105 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "oficina de administración",
"definition":"(sust. f.) administration office",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/oficina_de_administracion.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 106 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "otoño",
"definition":"(sust. m.) autumn",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/otono.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 107 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "pero",
"definition":"(conj.) but",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/pero.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 108 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "por la mañana",
"definition":"(exp.) in the morning",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/por_lamanana.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 109 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "por la tarde",
"definition":"(exp.) in the afternoon",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/por_la_tarde.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 110 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "¿Por qué?",
"definition":"(exp.) Why?",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/por_que.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 111 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "porque",
"definition":"(conj.) because",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/porque.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 112 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "primavera",
"definition":"(sust. f.) spring",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/primavera.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 113 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "programa",
"definition":"(sust. m.) program",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/programa.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 114 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "psicología",
"definition":"(sust. f.) psychology",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/psicologia.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 115 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "pues",
"definition":"(conj.) then, well",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/pues.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 116 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "que",
"definition":"(conj./pron.) who, that",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/que.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 117 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "¿Qué día es hoy?",
"definition":"(exp.) What day is it today?",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/que_dia_es_hoy.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 118 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "¿Qué fecha es hoy?",
"definition":"(exp.) What is the date today?",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/que_fecha_es_hoy.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 119 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "¿Qué hora es?",
"definition":"(exp.) What time is it?",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/que_hora_es.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 120 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "química",
"definition":"(sust. f.) chemistry",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/quimica.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 121 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "requisito",
"definition":"(sust. m.) requirement",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/requisito.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 122 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "sábado",
"definition":"(sust. m.) Saturday",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/sabado.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 123 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "semestre",
"definition":"(sust. m.) semester",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/semestre.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 124 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "este semestre",
"definition":"(exp.) this semester",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/este_semestre.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 125 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "septiembre",
"definition":"(sust. m.) September",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/septiembre.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 126 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "sesenta",
"definition":"(sust. m.) sixty",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/sesenta.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 127 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "setenta",
"definition":"(sust. m.) seventy",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/setenta.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 128 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "sociología",
"definition":"(sust. f.) sociology",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/sociologia.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 129 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "solamente",
"definition":"(adv.) only",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/solamente.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 130 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "sólo",
"definition":"(adv.) only",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/solo.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 131 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "también",
"definition":"(adv.) also, too",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/tambien.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 132 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "tarde",
"definition":"(sust. f.) afternoon",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/tarde.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 133 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "ya es tarde",
"definition":"(exp.) it’s already late",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/ya_es_tarde.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 134 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "tarea",
"definition":"(sust. f.) homework",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/tarea.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 135 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "té",
"definition":"(sust. m.) tea",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/te.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 136 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "té frío",
"definition":"(sust. m.) iced tea",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/te_frio.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 137 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "tele",
"definition":"(sust. f.) television",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/tele.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 138 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "televisión",
"definition":"(sust. f.) television",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/television.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 139 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "terminar",
"definition":"(v.) to end, to ﬁnish, to get through",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/terminar.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 140 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "tinto",
"definition":"(adj.) red (wine)",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/tinto.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 141 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "todo(-a)(-s)",
"definition":"(adj.) all, every",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/todo_a_s.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 142 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "tomar",
"definition":"(v.) to take (a class); to drink",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/tomar.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 143 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "toronja",
"definition":"(sust. f.) grapefruit",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/toronja.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 144 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "trabajar",
"definition":"(v.) to work",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/trabajar.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 145 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "uva(s)",
"definition":"(sust. f. sing./f. pl.) grape(s)",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/uva_s.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 146 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "vaso",
"definition":"(sust. m.) (drinking) glass",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/vaso.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 147 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "verano",
"definition":"(sust. m.) summer",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/verano.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 148 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "¿Verdad?",
"definition":"(exp.) Right?, True?",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/verdad.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 149 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "vida",
"definition":"(sust. f.) life",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/vida.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 150 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "viernes",
"definition":"(sust. m.) Friday",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/viernes.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 151 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "vino",
"definition":"(sust. m.) wine",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/vino.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 152 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "vino blanco",
"definition":"(sust. m.) white wine",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/vino_blanco.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 153 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "vino rosado",
"definition":"(sust. m.) rosé wine",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/vino_rosado.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 154 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "vino tinto",
"definition":"(sust. m.) red wine",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/vino_tinto.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 155 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "y media",
"definition":"(exp.) half past",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/y_media.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 156 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "copa",
"definition":"(sust. f.) wineglass",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/copa.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 157 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "taza",
"definition":"(sust. f.) cup",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/taza.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 158 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "la biblioteca",
"definition":"(sust. f.) library",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/biblioteca.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 159 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "el cumpleaños",
"definition":"(sust. m. sing.) birthday",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/cumpleanos.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 160 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "la librería",
"definition":"(sust. m.) bookstore",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/libreria.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 161 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "el ﬁn de semana",
"definition":"(sust. m.) weekend",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/fin_de_semana.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 162 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "la semana",
"definition":"(sust. f.) week",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/semana.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 163 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "practicar",
"definition":"(v.) to practise",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/practicar.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 164 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "por la noche",
"definition":"(exp.) at night",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/por_la_noche.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 165 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "el francés",
"definition":"(sust. m.) French",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/el_frances.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 166 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "cuarenta y uno",
"definition":"(sust. m.) forty-one",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/cuarenta_uno.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 167 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "cuarenta y cinco",
"definition":"(sust. m.) forty-five",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/cuarenta_cinco.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 168 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "ciento uno",
"definition":"(sust. m.) one hundred and one",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/ciento_uno.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 169 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "ciento quince",
"definition":"(sust. m.) one hundred and fifteen",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/ciento_quince.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 170 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "ciento setenta y cinco",
"definition":"(sust. m.) one hundred and seventy-five",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/ciento_setenta_cinco.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 171 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "ciento ochenta",
"definition":"(sust. m.) one hundred and eighty",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/ciento_ochenta.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 172 Term Audio transcript goes here...",
"definition_audio_transcript":""
},


]