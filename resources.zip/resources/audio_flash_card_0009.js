const flash_card_det9 = [
{
"term": "andar descalzo(-a)",
"definition":"(exp.) to go barefoot",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/andar_descalzo_a.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 1 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "apretar (e > ie)",
"definition":"(v.) to be tight",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/apretar_e_ie.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 2 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "arete(-s)",
"definition":"(sust. m. sing./m. pl.) earring(s)",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/arete_s.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 3 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "bata",
"definition":"(sust. f.) robe",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/bata.mp3",
"definition_audio":"",
"term_audio_transcript":"Card  Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "billetera",
"definition":"(sust. f.) wallet",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/billetera.mp3",
"definition_audio":"",
"term_audio_transcript":"Card  Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "blusa",
"definition":"(sust. f.) blouse",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/blusa.mp3",
"definition_audio":"",
"term_audio_transcript":"Card  Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "bufanda",
"definition":"(sust. f.) scarf",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/bufanda.mp3",
"definition_audio":"",
"term_audio_transcript":"Card  Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "buscar",
"definition":"(v.) to look for, to get",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/buscar.mp3",
"definition_audio":"",
"term_audio_transcript":"Card  Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "cadena",
"definition":"(sust. f.) chain",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/cadena.mp3",
"definition_audio":"",
"term_audio_transcript":"Card  Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "calcetín(-ines)",
"definition":"(sust. m. sing./m. pl.) sock(s)",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/calcetin_ines.mp3",
"definition_audio":"",
"term_audio_transcript":"Card  Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "cálido(-a)",
"definition":"(adj.) hot",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/calido_a.mp3",
"definition_audio":"",
"term_audio_transcript":"Card  Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "calzar",
"definition":"(v.) to wear a certain shoe size",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/calzar.mp3",
"definition_audio":"",
"term_audio_transcript":"Card  Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "calzoncillos",
"definition":"(sust. m. pl.) underpants",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/calzoncillos.mp3",
"definition_audio":"",
"term_audio_transcript":"Card  Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "camisa",
"definition":"(sust. f.) shirt",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/camisa.mp3",
"definition_audio":"",
"term_audio_transcript":"Card  Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "camiseta",
"definition":"(sust. f.) T-shirt",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/camiseta.mp3",
"definition_audio":"",
"term_audio_transcript":"Card  Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "camisón",
"definition":"(sust. m.) nightgown",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/camison.mp3",
"definition_audio":"",
"term_audio_transcript":"Card  Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "chaleco",
"definition":"(sust. m.) vest",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/chaleco.mp3",
"definition_audio":"",
"term_audio_transcript":"Card  Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "chaqueta",
"definition":"(sust. f.) jacket",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/chaqueta.mp3",
"definition_audio":"",
"term_audio_transcript":"Card  Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "cielo",
"definition":"(sust. m.) sky",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/el_cielo.mp3",
"definition_audio":"",
"term_audio_transcript":"Card  Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "El cielo está despejado.",
"definition":"(exp.) The sky is clear.",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/el_cielo_esta_despejado.mp3",
"definition_audio":"",
"term_audio_transcript":"Card  Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "El cielo está nublado.",
"definition":"(exp.) The sky is cloudy.",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/el_cielo_esta_nublado.mp3",
"definition_audio":"",
"term_audio_transcript":"Card  Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "cinturón",
"definition":"(sust. m.) belt",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/cinturon.mp3",
"definition_audio":"",
"term_audio_transcript":"Card  Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "clima",
"definition":"(sust. m.) climate",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/clima.mp3",
"definition_audio":"",
"term_audio_transcript":"Card  Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "como",
"definition":"(prep.) like",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/como.mp3",
"definition_audio":"",
"term_audio_transcript":"Card  Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "cómodo(-a)",
"definition":"(adj.) comfortable",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/comodo_a.mp3",
"definition_audio":"",
"term_audio_transcript":"Card  Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "corbata",
"definition":"(sust. f.) tie",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/corbata.mp3",
"definition_audio":"",
"term_audio_transcript":"Card  Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "corto(-a)",
"definition":"(adj.) short (in length)",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/corto_a.mp3",
"definition_audio":"",
"term_audio_transcript":"Card  Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "en cuanto",
"definition":"(exp.) as soon as",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/en_cuanto.mp3",
"definition_audio":"",
"term_audio_transcript":"Card  Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "debajo (de)",
"definition":"(adv.) under",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/debajo_de.mp3",
"definition_audio":"",
"term_audio_transcript":"Card  Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "despejado(-a)",
"definition":"(adj.) clear (sky)",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/despejado_a.mp3",
"definition_audio":"",
"term_audio_transcript":"Card  Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "empleado(-a)",
"definition":"(sust. m./ f.) clerk",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/empleado_a.mp3",
"definition_audio":"",
"term_audio_transcript":"Card  Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "escuela",
"definition":"(sust. f.) school",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/escuela.mp3",
"definition_audio":"",
"term_audio_transcript":"Card  Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "estar de moda",
"definition":"(exp.) to be in style",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/estar_de_moda.mp3",
"definition_audio":"",
"term_audio_transcript":"Card  Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "exactamente",
"definition":"(adv.) exactly",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/exactamente.mp3",
"definition_audio":"",
"term_audio_transcript":"Card  Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "facultad",
"definition":"(sust. f.) college",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/facultad.mp3",
"definition_audio":"",
"term_audio_transcript":"Card  Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "falda",
"definition":"(sust. f.) skirt",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/falda.mp3",
"definition_audio":"",
"term_audio_transcript":"Card  Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "frío(-a)",
"definition":"(adj.) cold",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/frio_a.mp3",
"definition_audio":"",
"term_audio_transcript":"Card  Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "gastar",
"definition":"(v.) to spend (money)",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/gastar.mp3",
"definition_audio":"",
"term_audio_transcript":"Card  Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "grado",
"definition":"(sust. m.) degree (temperature)",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/grado.mp3",
"definition_audio":"",
"term_audio_transcript":"Card  Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "Hay...grados.",
"definition":"(exp.) It's...degrees. ",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/hay_grados.mp3",
"definition_audio":"",
"term_audio_transcript":"Card  Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "guante(-s)",
"definition":"(sust. m. sing./pl.) glove(s)",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/guante_s.mp3",
"definition_audio":"",
"term_audio_transcript":"Card  Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "húmedo(-a)",
"definition":"(adj.) humid",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/humedo_a.mp3",
"definition_audio":"",
"term_audio_transcript":"Card  Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "impermeable",
"definition":"(sust. m.) raincoat",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/impermeable.mp3",
"definition_audio":"",
"term_audio_transcript":"Card  Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "incómodo(-a)",
"definition":"(adj.) uncomfortable",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/incomodo_a.mp3",
"definition_audio":"",
"term_audio_transcript":"Card  Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "largo(-a)",
"definition":"(adj.) long",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/largo_a.mp3",
"definition_audio":"",
"term_audio_transcript":"Card  Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "llover (o>ue)",
"definition":"(v.) to rain",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/llover_o_ue.mp3",
"definition_audio":"",
"term_audio_transcript":"Card  Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "lluvia",
"definition":"(sust. f.) rain",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/lluvia.mp3",
"definition_audio":"",
"term_audio_transcript":"Card  Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "lo que",
"definition":"(rel. pron.) what, that, which",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/lo_que.mp3",
"definition_audio":"",
"term_audio_transcript":"Card  Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "manga",
"definition":"(sust. f.) sleeve",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/manga.mp3",
"definition_audio":"",
"term_audio_transcript":"Card  Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "mediano(-a)",
"definition":"(adj.) medium",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/mediano_a.mp3",
"definition_audio":"",
"term_audio_transcript":"Card  Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "nevar (e>ie)",
"definition":"(v.) to snow",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/nevar_e_ie.mp3",
"definition_audio":"",
"term_audio_transcript":"Card  Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "niebla",
"definition":"(sust. f.) fog",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/niebla.mp3",
"definition_audio":"",
"term_audio_transcript":"Card  Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "nieve",
"definition":"(sust. f.) snow",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/nieve.mp3",
"definition_audio":"",
"term_audio_transcript":"Card  Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "nublado(-a)",
"definition":"(adj.) cloudy",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/nublado_a.mp3",
"definition_audio":"",
"term_audio_transcript":"Card  Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "oro",
"definition":"(sust. m.) gold",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/oro.mp3",
"definition_audio":"",
"term_audio_transcript":"Card  Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "pantalón (pantalones)",
"definition":"(sust. m. sing./m. pl.) pants, trousers",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/pantalon_pantalones.mp3",
"definition_audio":"",
"term_audio_transcript":"Card  Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "pantalones cortos",
"definition":"(sust. m. pl.) shorts",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/pantalones_cortos.mp3",
"definition_audio":"",
"term_audio_transcript":"Card  Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "par",
"definition":"(sust. m.) pair",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/par.mp3",
"definition_audio":"",
"term_audio_transcript":"Card  Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "paraguas",
"definition":"(sust. m.) umbrella",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/paraguas.mp3",
"definition_audio":"",
"term_audio_transcript":"Card  Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "pijama(-s)",
"definition":"(sust. m. sing./m. pl.) pajamas",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/pijama_s.mp3",
"definition_audio":"",
"term_audio_transcript":"Card  Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "probador",
"definition":"(sust. m.) fitting room",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/probador.mp3",
"definition_audio":"",
"term_audio_transcript":"Card  Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "¿En qué puedo servirle?",
"definition":"(exp.) How may I help you?",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/en_que_puedo_servirle.mp3",
"definition_audio":"",
"term_audio_transcript":"Card  Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "¿Qué temperatura hace?",
"definition":"(exp.) What's the temperature?",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/que_temperatura_hace.mp3",
"definition_audio":"",
"term_audio_transcript":"Card  Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "quedarle chico(-a) (a alguien)",
"definition":"(exp.) to be too small on someone",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/quedarle_chico_a_alguien.mp3",
"definition_audio":"",
"term_audio_transcript":"Card  Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "quedarle grande (a alguien)",
"definition":"(exp.) to be too big on someone",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/quedarle_grande_a_alguien.mp3",
"definition_audio":"",
"term_audio_transcript":"Card  Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "quizás",
"definition":"(adv.) maybe, perhaps",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/quizas.mp3",
"definition_audio":"",
"term_audio_transcript":"Card  Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "ramo",
"definition":"(sust. m.) a bouquet, a bunch",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/ramo.mp3",
"definition_audio":"",
"term_audio_transcript":"Card  Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "regalar",
"definition":"(v.) to give a gift",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/regalar.mp3",
"definition_audio":"",
"term_audio_transcript":"Card  Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "regalo",
"definition":"(sust. m.) gift",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/regalo.mp3",
"definition_audio":"",
"term_audio_transcript":"Card  Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "seco(-a)",
"definition":"(adj.) dry",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/seco_a.mp3",
"definition_audio":"",
"term_audio_transcript":"Card  Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "sostén",
"definition":"(sust. m.) bra",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/sosten.mp3",
"definition_audio":"",
"term_audio_transcript":"Card  Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "suéter",
"definition":"(sust. m.) sweater",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/sueter.mp3",
"definition_audio":"",
"term_audio_transcript":"Card  Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "sujetador",
"definition":"(sust. m.) bra",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/sujetador.mp3",
"definition_audio":"",
"term_audio_transcript":"Card  Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "tacaño(-a)",
"definition":"(adj.) frugal, stingy",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/tacano_a.mp3",
"definition_audio":"",
"term_audio_transcript":"Card  Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "tacón",
"definition":"(sust. m.) heel",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/tacon.mp3",
"definition_audio":"",
"term_audio_transcript":"Card  Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "tal vez",
"definition":"(exp.) maybe, perhaps",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/tal_vez.mp3",
"definition_audio":"",
"term_audio_transcript":"Card  Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "talla",
"definition":"(sust. f.) size (of clothing)",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/talla.mp3",
"definition_audio":"",
"term_audio_transcript":"Card  Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "temperatura",
"definition":"(sust. f.) temperature",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/temperatura.mp3",
"definition_audio":"",
"term_audio_transcript":"Card  Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "templado(-a)",
"definition":"(adj.) warm",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/templado_a.mp3",
"definition_audio":"",
"term_audio_transcript":"Card  Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "no tener nada que ponerse",
"definition":"(exp.) to have nothing to wear",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/no_tener_nada_que_ponerse.mp3",
"definition_audio":"",
"term_audio_transcript":"Card  Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "tienda",
"definition":"(sust. f.) store",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/tienda.mp3",
"definition_audio":"",
"term_audio_transcript":"Card  Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "traje",
"definition":"(sust. m.) suit",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/traje.mp3",
"definition_audio":"",
"term_audio_transcript":"Card  Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "usar",
"definition":"(v.) to use, to wear",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/usar.mp3",
"definition_audio":"",
"term_audio_transcript":"Card  Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "vaqueros",
"definition":"(sust. m. pl.) jeans",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/vaqueros.mp3",
"definition_audio":"",
"term_audio_transcript":"Card  Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "zapatería",
"definition":"(sust. f.) shoe store",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/zapateria.mp3",
"definition_audio":"",
"term_audio_transcript":"Card  Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "zapatilla(-s)",
"definition":"(sust. f. sing./f. pl.) slipper(s)",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/zapatilla_s.mp3",
"definition_audio":"",
"term_audio_transcript":"Card  Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "zapato(-s)",
"definition":"(sust. m. sing./m. pl.) shoe(s)",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/zapato_s.mp3",
"definition_audio":"",
"term_audio_transcript":"Card  Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "tarjeta",
"definition":"(sust. f.) card",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/tarjeta.mp3",
"definition_audio":"",
"term_audio_transcript":"Card  Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "sandalias",
"definition":"(sust. f. pl.) sandals",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/sandalias.mp3",
"definition_audio":"",
"term_audio_transcript":"Card  Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "tren",
"definition":"(sust. m.) train",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/tren.mp3",
"definition_audio":"",
"term_audio_transcript":"Card  Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "comprar en línea",
"definition":"(exp.) to buy online",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/comprar en linea.mp3",
"definition_audio":"",
"term_audio_transcript":"Card  Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "costar (o > ue) una fortuna",
"definition":"(exp.) to cost a fortune",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/costar_fortuna.mp3",
"definition_audio":"",
"term_audio_transcript":"Card  Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "bolso ",
"definition":"(sust. m.) handbag, purse",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/el bolso.mp3",
"definition_audio":"",
"term_audio_transcript":"Card  Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "centro comercial ",
"definition":"(sust. m.) mall",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/el centro comercial.mp3",
"definition_audio":"",
"term_audio_transcript":"Card  Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "fresco (-a)",
"definition":"(adj.) fresh, cool",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/fresco_fresca.mp3",
"definition_audio":"",
"term_audio_transcript":"Card  Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "gorra ",
"definition":"(sust. f.) baseball hat",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/la gorra.mp3",
"definition_audio":"",
"term_audio_transcript":"Card  Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "gorro ",
"definition":"(sust. m.) toque",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/el gorro.mp3",
"definition_audio":"",
"term_audio_transcript":"Card  Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "sudadera",
"definition":"(sust. f.) sweatshirt",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/la sudadera.mp3",
"definition_audio":"",
"term_audio_transcript":"Card  Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "sudadera con capucha ",
"definition":"(sust. f.) hoodie",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/la sudadera con campucha",
"definition_audio":"",
"term_audio_transcript":"Card  Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "zapatos deportivos ",
"definition":"(sust. f.) sneakers",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/los zapatos deportivos.mp3",
"definition_audio":"",
"term_audio_transcript":"Card  Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": " dependiente (a)",
"definition":"(sust. m./f.) salesclerk",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/dependiente2.mp3",
"definition_audio":"",
"term_audio_transcript":"Card  Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "braga",
"definition":"(sust. f.) panties",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/braga.mp3",
"definition_audio":"",
"term_audio_transcript":"Card  Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "vestido",
"definition":"(sust. m.) dress",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/vestido.mp3",
"definition_audio":"",
"term_audio_transcript":"Card  Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "botas",
"definition":"(sust. f. pl.) boots",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/botas.mp3",
"definition_audio":"",
"term_audio_transcript":"Card  Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "Hace fresco.",
"definition":"(exp.) It´s cool.",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/hace_fresco.mp3",
"definition_audio":"",
"term_audio_transcript":"Card  Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "Llueve. / Está lloviendo.",
"definition":"(exp.) It's raining",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/llueve_lloviendo.mp3",
"definition_audio":"",
"term_audio_transcript":"Card  Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "Nieva. / Está nevando.",
"definition":"(exp.) It's snowing",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/nieva_nevando.mp3 ",
"definition_audio":"",
"term_audio_transcript":"Card  Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "Hay niebla.",
"definition":"(exp.) It's foggy",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/hay_niebla.mp3",
"definition_audio":"",
"term_audio_transcript":"Card  Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "Hace buen tiempo.",
"definition":"(exp.) It´s nice weather.",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/hace_tiempo.mp3",
"definition_audio":"",
"term_audio_transcript":"Card  Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "Hace sol.",
"definition":"(exp.) It´s sunny.",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/hace_sol.mp3",
"definition_audio":"",
"term_audio_transcript":"Card  Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "Hace frío.",
"definition":"(exp.) It´s cold.",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/hace_frio.mp3",
"definition_audio":"",
"term_audio_transcript":"Card  Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "Hace viento.",
"definition":"(exp.) It´s windy.",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/hace_viento.mp3",
"definition_audio":"",
"term_audio_transcript":"Card  Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "Hace mal tiempo.",
"definition":"(exp.) It´s bad weather.",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/p9_8a.mp3",
"definition_audio":"",
"term_audio_transcript":"Card  Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "abrigo",
"definition":"(sust. m.) coat",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/abrigo.mp3",
"definition_audio":"",
"term_audio_transcript":"Card  Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "alto(a)",
"definition":"(adj.) high, tall",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/alto_a.mp3",
"definition_audio":"",
"term_audio_transcript":"Card  Term Audio transcript goes here...",
"definition_audio_transcript":""
},



]