const flash_card_det13 = [
	
{
"term": "cero",
"definition":"0",
"term_audio":""
},
{
"term": "uno",
"definition":"1",
"term_audio":""
},
{
"term": "dos",
"definition":"2",
"term_audio":""
},
{
"term": "tres",
"definition":"3",
"term_audio":""
},
{
"term": "cuatro",
"definition":"4",
"term_audio":""
},
{
"term": "cinco",
"definition":"5",
"term_audio":""
},
{
"term": "seis",
"definition":"6",
"term_audio":""
},
{
"term": "siete",
"definition":"7",
"term_audio":""
},
{
"term": "ocho",
"definition":"8",
"term_audio":""
},
{
"term": "nueve",
"definition":"9",
"term_audio":""
},
{
"term": "diez",
"definition":"10",
"term_audio":""
},
{
"term": "once",
"definition":"11",
"term_audio":""
},
{
"term": "doce",
"definition":"12",
"term_audio":""
},
{
"term": "trece",
"definition":"13",
"term_audio":""
},
{
"term": "catorce",
"definition":"14",
"term_audio":""
},
{
"term": "quince",
"definition":"15",
"term_audio":""
},
{
"term": "dieciséis",
"definition":"16",
"term_audio":""
},
{
"term": "diecisiete",
"definition":"17",
"term_audio":""
},
{
"term": "dieciocho",
"definition":"18",
"term_audio":""
},
{
"term": "diecinueve",
"definition":"19",
"term_audio":""
},
{
"term": "veinte",
"definition":"20",
"term_audio":""
},
{
"term": "veintiuno",
"definition":"21",
"term_audio":""
},
{
"term": "veintidós",
"definition":"22",
"term_audio":""
},
{
"term": "veintitrés",
"definition":"23",
"term_audio":""
},
{
"term": "veinticuatro",
"definition":"24",
"term_audio":""
},
{
"term": "veinticinco",
"definition":"25",
"term_audio":""
},
{
"term": "veintiséis",
"definition":"26",
"term_audio":""
},
{
"term": "veintisiete",
"definition":"27",
"term_audio":""
},
{
"term": "veintiocho",
"definition":"28",
"term_audio":""
},
{
"term": "veintinueve",
"definition":"29",
"term_audio":""
},
{
"term": "treinta",
"definition":"30",
"term_audio":""
},
{
"term": "treinta y uno",
"definition":"31",
"term_audio":""
},
{
"term": "treinta y dos",
"definition":"32",
"term_audio":""
},
{
"term": "treinta y tres",
"definition":"33",
"term_audio":""
},
{
"term": "treinta y cuatro",
"definition":"34",
"term_audio":""
},
{
"term": "treinta y cinco",
"definition":"35",
"term_audio":""
},
{
"term": "treinta y seis",
"definition":"36",
"term_audio":""
},
{
"term": "treinta y siete",
"definition":"37",
"term_audio":""
},
{
"term": "treinta y ocho",
"definition":"38",
"term_audio":""
},
{
"term": "treinta y nueve",
"definition":"39",
"term_audio":""
},
{
"term": "cuarenta",
"definition":"40",
"term_audio":""
},
{
"term": "cuarenta y uno",
"definition":"41",
"term_audio":""
},
{
"term": "cuarenta y dos",
"definition":"42",
"term_audio":""
},
{
"term": "cuarenta y tres ",
"definition":"43",
"term_audio":""
},
{
"term": "cuarenta y cuatro",
"definition":"44",
"term_audio":""
},
{
"term": "cuarenta y cinco",
"definition":"45",
"term_audio":""
},
{
"term": "cuarenta y seis",
"definition":"46",
"term_audio":""
},
{
"term": "cuarenta y siete",
"definition":"47",
"term_audio":""
},
{
"term": "cuarenta y ocho",
"definition":"48",
"term_audio":""
},
{
"term": "cuarenta y nueve",
"definition":"49",
"term_audio":""
},
{
"term": "cincuenta",
"definition":"50",
"term_audio":""
}
]





