const flash_card_det3 = [
	
{
"term": "aparatos electrodomésticos",
"definition":"(sust. m. pl.) home appliances",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/aparatos_electrodomesticos.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 1 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "aprender",
"definition":"(v.) to learn",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/aprender.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 2 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "aquel, aquello(-a)(-s)",
"definition":"(pron.) that, those",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/aquel_aquello_a_s.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 3 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "arreglar",
"definition":"(v.) to tidy up",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/arreglar.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 4 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "aspiradora",
"definition":"(sust. f.) vacuum",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/aspiradora.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 5 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "ayudar",
"definition":"(v.) to help",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/ayudar.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 6 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "baño",
"definition":"(sust. m.) bathroom",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/bano.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 7 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "cuarto de baño",
"definition":"(sust. m.) bathroom",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/cuarto_de_bano.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 8 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "barrer",
"definition":"(v.) to sweep",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/barrer.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 9 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "basura",
"definition":"(sust. f.) garbage",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/basura.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 10 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "beber",
"definition":"(v.) to drink",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/beber.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 11 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "cacerola",
"definition":"(sust. f.) saucepan",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/cacerola.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 12 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "cafetera",
"definition":"(sust. f.) coffeepot",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/cafetera.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 13 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "casa",
"definition":"(sust. f.) house",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/casa.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 14 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "ciudad",
"definition":"(sust. f.) city",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/ciudad.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 15 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "cocina",
"definition":"(sust. f.) kitchen, stove",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/cocina.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 16 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "comedor",
"definition":"(sust. m.) dining room",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/comedor.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 17 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "comer",
"definition":"(v.) to eat",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/comer.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 18 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "comida",
"definition":"(sust. f.) meal, food",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/comida.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 19 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "conmigo",
"definition":"(pron.) with me",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/conmigo.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 20 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "correo electrónico",
"definition":"(sust. m.) email",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/el correo electronico.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 21 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "correr",
"definition":"(v.) to run",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/correr.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 22 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "cosa",
"definition":"(sust. f.) thing",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/cosa.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 23 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "cosas que hacer",
"definition":"(exp.) things to do",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/cosas_que_hacer.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 24 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "creer",
"definition":"(v.) to believe",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/creer.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 25 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "cuando",
"definition":"(conj.) when",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/cuando.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 26 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "cuarto",
"definition":"(sust. m.) room",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/cuarto.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 27 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "cuatrocientos",
"definition":"(sust. m.) four hundred",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/cuatrocientos.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 28 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "deber",
"definition":"(v.) to have to, must, should",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/deber.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 29 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "desastre",
"definition":"(sust. m.) disaster",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/desastre.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 30 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "descansar",
"definition":"(v.) to rest",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/descansar.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 31 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "después",
"definition":"(adv.) afterwards",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/despues.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 32 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "dividir",
"definition":"(v.) to divide",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/dividir.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 33 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "dormitorio",
"definition":"(sust. m.) bedroom",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/dormitorio.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 34 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "ensalada",
"definition":"(sust. f.) salad",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/ensalada.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 35 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "escribir",
"definition":"(v.) to write",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/escribir.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 36 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "eso",
"definition":"(pron.) that",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/eso.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 37 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "especialmente",
"definition":"(adv.) especially",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/especialmente.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 38 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "este(-a)",
"definition":"(adj.) this",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/este_a.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 39 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "excusa",
"definition":"(sust. f.) excuse",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/excusa.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 40 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "familia",
"definition":"(sust. f.) family",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/familia.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 41 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "favorito(-a)",
"definition":"(adj.) favourite",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/favorito_a.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 42 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "garaje",
"definition":"(sust. m.) garage",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/garaje.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 43 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "hacer",
"definition":"(v.) to do, to make",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/hacer.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 44 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "horno",
"definition":"(sust. m.) oven",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/horno.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 45 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "horno de microondas",
"definition":"(sust. m.) microwave oven",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/horno_de_microondas.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 46 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "lavadora",
"definition":"(sust. f.) washing machine",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/lavadora.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 47 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "lavaplatos",
"definition":"(sust. m.) dishwasher",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/lavaplatos.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 48 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "lavar",
"definition":"(v.) to wash",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/lavar.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 49 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "leer",
"definition":"(v.) to read",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/leer.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 50 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "licuadora",
"definition":"(sust. f.) blender",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/licuadora.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 51 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "limonada",
"definition":"(sust. f.) lemonade",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/limonada.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 52 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "limpiar",
"definition":"(v.) to clean",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/limpiar.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 53 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "llamar a la puerta",
"definition":"(exp.) to knock at the door",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/llamar_a_la_puerta.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 54 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "llegar",
"definition":"(v.) to arrive",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/llegar.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 55 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "mil",
"definition":"(sust. m.) a thousand",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/mil.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 56 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "mirar",
"definition":"(v.) to watch, to look at",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/mirar.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 57 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "momento",
"definition":"(sust. m.) moment",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/momento.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 58 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "mueble(-s)",
"definition":"(sust. m. sing./m. pl.) furniture",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/mueble_s.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 59 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "novecientos",
"definition":"(sust. m.) nine hundred",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/novecientos.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 60 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "ochocientos",
"definition":"(sust. m.) eight hundred",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/ochocientos.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 61 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "para",
"definition":"(prep.) for, in order to",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/para.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 62 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "pasar la aspiradora",
"definition":"(exp.) to vacuum",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/pasar_la_aspiradora.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 63 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "plancha",
"definition":"(sust. f.) iron",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/plancha.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 64 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "planchar",
"definition":"(v.) to iron",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/planchar.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 65 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "preparar",
"definition":"(v.) to prepare",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/preparar.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 66 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "¿Quién es?",
"definition":"(exp.) Who is it?",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/quien_es.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 67 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "quinientos",
"definition":"(sust. m.) five hundred",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/quinientos.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 68 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "rápidamente",
"definition":"(adv.) quickly",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/rapidamente.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 69 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "un rato",
"definition":"(exp.) a while",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/un_rato.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 70 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "recibir",
"definition":"(v.) to receive",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/recibir.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 71 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "refrigerador",
"definition":"(sust. m.) refrigerator",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/refrigerador.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 72 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "ropa",
"definition":"(sust. f.) clothes",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/ropa.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 73 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "sacar",
"definition":"(v.) to take out",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/sacar.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 74 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "sala",
"definition":"(sust. f.) living room",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/sala.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 75 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "sala de estar",
"definition":"(sust. f.) living room",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/sala_de_estar.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 76 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "sartén",
"definition":"(sust. f.) frying pan",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/sarten.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 77 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "secadora",
"definition":"(sust. f.) dryer, clothes dryer",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/secadora.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 78 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "secar",
"definition":"(v.) to dry",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/secar.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 79 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "seiscientos",
"definition":"(sust. m.) six hundred",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/seiscientos.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 80 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "setecientos",
"definition":"(sust. m.) seven hundred",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/setecientos.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 81 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "siempre",
"definition":"(adv.) always",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/siempre.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 82 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "sucio(-a)",
"definition":"(adj.) dirty",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/sucio_a.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 83 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "telenovela",
"definition":"(sust. f.) soap opera",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/telenovela.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 84 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "tener",
"definition":"(v.) to have",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/tener.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 85 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "tener… años (de edad)",
"definition":"(exp.) to be … years old",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/tenera_a_os_de_edad.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 86 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "no tener razón",
"definition":"(exp.) to be wrong",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/no_tenerrazon.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 87 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "tener calor",
"definition":"(exp.) to be hot",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/tener_calor.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 88 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "tener cuidado",
"definition":"(exp.) to be careful",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/tener_cuidado.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 89 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "tener éxito",
"definition":"(exp.) to be successful",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/tener_exito.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 90 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "tener frío",
"definition":"(exp.) to be cold",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/tener_frio.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 91 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "tener hambre",
"definition":"(exp.) to be hungry",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/tener_hambre.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 92 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "tener miedo",
"definition":"(exp.) to be afraid, scared",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/tener_miedo.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 93 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "tener prisa",
"definition":"(exp.) to be in a hurry",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/tener_prisa.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 94 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "tener que (+ inf.)",
"definition":"(exp.) to have to (doing something)",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/tener_que_inf.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 95 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "tener razón",
"definition":"(exp.) to be right",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/tener_razon.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 96 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "tener sed",
"definition":"(exp.) to be thirsty",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/tener_sed.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 97 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "tener sueño",
"definition":"(exp.) to be sleepy",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/tener_sueno.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 98 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "tener suerte",
"definition":"(exp.) to be lucky",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/tener_suerte.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 99 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "tiempo",
"definition":"(sust. m.) time, weather",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/tiempo.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 100 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "tocar a la puerta",
"definition":"(exp.) to knock at the door",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/tocar_a_la_puerta.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 101 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "todavía",
"definition":"(adv.) still",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/todavia.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 102 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "tostadora",
"definition":"(sust. f.) toaster",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/tostadora.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 103 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "trabajo",
"definition":"(sust. m.) work",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/trabajo.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 104 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "los trabajos de la casa, los quehaceres",
"definition":"(sust. m.) housework",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/los_trabajos.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 105 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "trescientos",
"definition":"(sust. m.) three hundred",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/trescientos.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 106 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "venir (e>ie)",
"definition":"(v.) to come",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/venir_e_ie.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 107 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "vivir",
"definition":"(v.) to live",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/vivir.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 108 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "compartir",
"definition":"(v.) to share",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/compartir.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 109 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "hermano(-a)",
"definition":"(sust. m./f.) brother / sister",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/hermano_a.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 110 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "hijo(-a)",
"definition":"(sust. m./f.) son / daughter",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/hijo_a.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 111 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "mamá",
"definition":"(sust. f.) mom",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/mama.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 112 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "padres",
"definition":"(sust. m. pl.) parents",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/padres.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 113 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "papá",
"definition":"(sust. m.) dad",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/papa_.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 114 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "plato",
"definition":"(sust. m.) plate, dish",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/plato.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 115 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "batería de cocina",
"definition":"(sust. f.) kitchen utensils",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/bateria_de_cocina.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 116 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "allá",
"definition":"(adv.) over there",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/alla.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 117 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "residencia estudiantil, residencia universitaria",
"definition":"(sust. f.) university residence",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/la residencia estudiantil.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 118 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "apartamento",
"definition":"(sust. m.) apartment",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/apartamento.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 119 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "mesa",
"definition":"(sust. f.) table",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/mesa.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 120 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "el mensaje de texto",
"definition":"(sust. m.) text message",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/el_mensaje.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 121 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "abrir",
"definition":"(v.) to open",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/abrir.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 122 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "antes (de)",
"definition":"(exp.) before",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/antes_de.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 123 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "allí",
"definition":"(adv.) there",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/alli.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 124 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "aquí",
"definition":"(adv.) here",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/aqui.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 125 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "dos mil",
"definition":"(sust. m.) two thousand",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/dos_mil.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 126 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "un millón",
"definition":"(sust. m.) one million",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/millon.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 127 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "dos millones",
"definition":"(sust. m.) two million",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/millones.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 128 Term Audio transcript goes here...",
"definition_audio_transcript":""
},




]