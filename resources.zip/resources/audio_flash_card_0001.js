const flash_card_det1 = [
	

{
"term": "alto(-a)",
"definition":"(adj.) tall",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/alto_a.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 1 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "alumno(-a)",
"definition":"(sust. m./f.) student",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/alumno_a.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 2 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "amarillo(-a)",
"definition":"(adj.) yellow",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/amarillo_a.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 3 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "anaranjado(-a)",
"definition":"(adj.) orange",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/anaranjado_a.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 4 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "antipático(-a)",
"definition":"(adj.) unpleasant",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/antipatico_a.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 5 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "azul",
"definition":"(sust. m./adj.) blue",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/azul.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 6 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "bajo(-a)",
"definition":"(adj.) short",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/bajo_a.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 7 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "biblioteca",
"definition":"(sust. f.) library",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/biblioteca.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 8 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "blanco(-a)",
"definition":"(adj.) white",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/blanco_a.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 9 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "bolígrafo",
"definition":"(sust. m.) ball-point pen",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/boligrafo.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 10 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "bonito(-a)",
"definition":"(adj.) pretty",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/bonito_a.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 11 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "borrador",
"definition":"(sust. m.) eraser",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/borrador.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 12 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "buen, bueno(-a)",
"definition":"(adj.) good",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/buen_bueno_a.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 13 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "cafetería",
"definition":"(sust. f.) cafeteria",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/cafeteria.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 14 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "calle",
"definition":"(sust. f.) street",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/calle.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 15 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "calle… número...",
"definition":"(exp.) … street, number …",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/callea_n_mero.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 16 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "canadiense",
"definition":"(adj.) Canadian",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/canadiense.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 17 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "cesto de papeles",
"definition":"(sust. m.) wastebasket",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/cesto_de_papeles.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 18 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "chico(-a)",
"definition":"(sust. m./f.) young man/woman",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/el_chico_la chica.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 19 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "clase",
"definition":"(sust. f.) class",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/clase.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 20 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "color",
"definition":"(sust. m.) colour",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/color.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 21 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "¿Cómo?",
"definition":"(exp.) Excuse me? (when one doesn’t understand or hear what is being said)",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/como_.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 22 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "¿Cómo es …?",
"definition":"(exp.) What is … like?",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/como_es.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 23 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "¿Cómo se dice…?",
"definition":"(exp.) How do you say …?",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/c_mo_se_dicea.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 24 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "compañero(-a)",
"definition":"(sust. m./f.) companion",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/companero_a.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 25 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "compañero(-a) de cuarto",
"definition":"(sust. m./f.) roommate",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/companero_a_de_cuarto.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 26 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "compañero(-a) de clase",
"definition":"(sust. m./f.) classmate",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/companero.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 27 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "con",
"definition":"(prep.) with",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/con_.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 28 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "cuaderno",
"definition":"(sust. m.) notebook",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/cuaderno.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 29 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "¿Cuál?",
"definition":"(adv.) Which? What?",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/cual.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 30 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "¿Cuál es?",
"definition":"(exp.) What is? Which one is?",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/cual_es.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 31 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "¿Cuál es su número de teléfono?",
"definition":"(exp.) What's your telephone number? (formal)",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/numero2.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 32 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "¿Cuál es tu dirección?",
"definition":"(exp.) What's your address?",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/cual_es_tu_direccion.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 33 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "Se dice…",
"definition":"(exp.) You say …",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/se_dicea.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 34 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "delgado(-a)",
"definition":"(adj.) slender",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/delgado_a.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 35 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "difícil",
"definition":"(adj.) difficult",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/dificil.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 36 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "dirección",
"definition":"(sust. f.) address",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/direccion.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 37 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "¿Dónde?",
"definition":"(adv.) Where?",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/donde.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 38 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "¿De dónde es usted?",
"definition":"(exp.) Where are you from? (formal)",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/de_donde_es_usted.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 39 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "¿De dónde eres?",
"definition":"(exp.) Where are you from? (familiar)",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/de_donde_eres.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 40 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "en",
"definition":"(prep.) at, in, on",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/en.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 41 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "Encantado(-a)",
"definition":"(exp.) The pleasure is mine.",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/encantado.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 42 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "escritorio",
"definition":"(sust. m.) desk",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/escritorio.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 43 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "español",
"definition":"(sust. m.) Spanish (language)",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/espanol.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 44 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "estadounidense",
"definition":"(adj.) American",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/estadounidense.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 45 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "estudiante",
"definition":"(sust. m./f.) student",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/estudiante.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 46 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "excelente",
"definition":"(adj.) excellent",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/excelente.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 47 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "fácil",
"definition":"(adj.) easy",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/facil.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 48 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "fantástico(-a)",
"definition":"(adj.) fantastic",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/fantastico_a.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 49 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "favorito(-a)",
"definition":"(adj.) favourite",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/favorito_a.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 50 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "feliz",
"definition":"(adj.) happy",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/feliz.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 51 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "feo(-a)",
"definition":"(adj.) ugly",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/feo_a.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 52 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "gordo(-a)",
"definition":"(adj.) fat",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/gordo_a.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 53 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "grande",
"definition":"(adj.) big",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/grande.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 54 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "gris",
"definition":"(sust. m./adj.) grey",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/gris.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 55 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "guapo(-a)",
"definition":"(adj.) handsome, beautiful",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/guapo_a.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 56 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "habla",
"definition":"(exp.) he/she speaks",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/habla.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 57 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "hay",
"definition":"(exp.) there is, there are",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/hay.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 58 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "hombre",
"definition":"(sust. m.) man",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/hombre.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 59 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "horrible",
"definition":"(adj.) horrible",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/horrible.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 60 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "inteligente",
"definition":"(adj.) intelligent",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/inteligente.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 61 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "interesante",
"definition":"(adj.) interesting",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/interesante.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 62 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "joven",
"definition":"(adj.) young",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/joven.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 63 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "lápiz",
"definition":"(sust. m.) pencil",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/lapiz.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 64 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "libro",
"definition":"(sust. m.) book",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/libro.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 65 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "lindo(-a)",
"definition":"(adj.) pretty",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/lindo_a.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 66 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "luz",
"definition":"(sust. f.) light",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/luz.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 67 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "malo(-a)",
"definition":"(adj.) bad",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/malo.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 68 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "el mapa",
"definition":"(sust. m) map",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/el_mapa.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 69 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "marcador",
"definition":"(sust. m.) felt-tip pen",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/marcador.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 70 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "Más despacio, por favor.",
"definition":"(exp.) More slowly, please.",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/mas_despacio_por_favor.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 71 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "mexicano(-a)",
"definition":"(adj.) Mexican",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/mexicano_a.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 72 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "mi",
"definition":"(adj.) my",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/mi.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 73 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "mochila",
"definition":"(sust. f.) backpack",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/mochila.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 74 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "morado(-a)",
"definition":"(sust. m./adj.) purple",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/morado_a.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 75 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "móvil",
"definition":"(sust. m.) cellphone",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/movil.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 76 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "muchacho(-a)",
"definition":"(sust. m./f.) young man/woman",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/muchacho_a.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 77 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "Muchas gracias.",
"definition":"(exp.) Thank you very much.",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/muchas_gracias.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 78 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "mucho(a)(s)",
"definition":"(adj.) a lot, many",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/mucho.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 79 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "No mucho.",
"definition":"(exp.) Not much.",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/no_mucho.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 80 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "mujer",
"definition":"(sust. f.) woman",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/mujer.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 81 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "muy",
"definition":"(adv.) very",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/muy.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 82 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "De nada.",
"definition":"(exp.) You’re welcome.",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/de_nada.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 83 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "negro(-a)",
"definition":"(sust. m./adj.) black",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/negro_a.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 84 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "no",
"definition":"(adv.) no, not",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/no.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 85 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "esta noche",
"definition":"(exp.) tonight",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/esta_noche.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 86 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "norteamericano(-a)",
"definition":"(adj.) North American",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/norteamericano_a.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 87 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "oye",
"definition":"(exp.) listen",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/oye.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 88 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "papel",
"definition":"(sust. m.) paper",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/papel.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 89 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "pared",
"definition":"(sust. f.) wall",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/pared.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 90 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "pequeño(-a)",
"definition":"(adj.) small",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/pequeno_a.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 91 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "Perdón.",
"definition":"(exp.) Sorry, pardon me.",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/perdon.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 92 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "perfecto(-a)",
"definition":"(adj.) perfect",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/perfecto_a.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 93 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "Permiso.",
"definition":"(exp.) Excuse me. (e.g., when going through a crowded room)",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/permiso..mp3",
"definition_audio":"",
"term_audio_transcript":"Card 94 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "Con permiso.",
"definition":"(exp.) Excuse me. (e.g., when going through a crowded room)",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/con_permiso.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 95 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "pizarra",
"definition":"(sust. f.) chalkboard",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/pizarra.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 96 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "pizarra blanca",
"definition":"(sust. f.) whiteboard",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/pizarra_blanca.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 97 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "pluma",
"definition":"(sust. f.) ball-point pen",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/pluma.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 98 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "pobre",
"definition":"(adj.) poor",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/pobre.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 99 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "Por favor.",
"definition":"(exp.) Please.",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/por_favor..mp3",
"definition_audio":"",
"term_audio_transcript":"Card 100 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "puerta",
"definition":"(sust. f.) door",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/puerta.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 101 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "pupitre",
"definition":"(sust. m.) desk",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/pupitre.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 102 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "¿Qué?",
"definition":"(pron.) What?",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/que_.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 103 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "¿Qué es?",
"definition":"(exp.) What is?",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/que_es.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 104 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "¿Qué hay de nuevo?",
"definition":"(exp.) What’s new?",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/que_hay_de_nuevo.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 105 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "¿Quién?",
"definition":"(pron.) Who?",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/quien.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 106 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "reloj",
"definition":"(sust. m.) clock, watch",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/reloj.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 107 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "rico(-a)",
"definition":"(adj.) rich",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/rico_a.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 108 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "rojo(-a)",
"definition":"(sust. m./adj.) red",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/rojo_a.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 109 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "rosado(-a)",
"definition":"(adj.) pink",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/rosado_a.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 110 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "Saludos a…",
"definition":"(exp.) Say hi to …",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/saludos_aa.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 111 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "Lo siento.",
"definition":"(exp.) I’m sorry.",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/lo_siento.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 112 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "ser",
"definition":"(v.) to be",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/ser.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 113 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "sí",
"definition":"(adv.) yes",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/si_.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 114 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "silla",
"definition":"(sust. f.) chair",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/silla.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 115 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "simpático(-a)",
"definition":"(adj.) charming, nice, fun to be with",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/simpatico_a.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 116 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "Soy de …",
"definition":"(exp.) I am from…",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/soy.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 117 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "teléfono celular",
"definition":"(sust. m.) cellphone",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/telefono_celular.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 118 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "terrible",
"definition":"(adj.) terrible",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/terrible.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 119 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "tiza",
"definition":"(sust. f.) chalk",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/tiza.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 120 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "tonto(-a)",
"definition":"(adj.) dumb",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/tonto_a.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 121 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "tu(-s)",
"definition":"(adj.) your",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/tu_s.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 122 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "universidad",
"definition":"(sust. f.) university",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/universidad.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 123 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "universitario(-a)",
"definition":"(adj.) (related to) university",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/universitario_a.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 124 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "ventana",
"definition":"(sust. f.) window",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/ventana.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 125 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "verde",
"definition":"(sust. m./adj.) green",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/verde.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 126 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "viejo(-a)",
"definition":"(adj.) old",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/viejo_a.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 127 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "violeta",
"definition":"(adj./sust. f.) purple",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/violeta.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 128 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "y",
"definition":"(conj.) and",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/y.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 129 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "computadora",
"definition":"(sust. f.) computer",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/computadora.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 130 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "computadora portátil",
"definition":"(sust. f.) laptop",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/computadorapersonal.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 131 Term Audio transcript goes here...",
"definition_audio_transcript":""
},
{
"term": "laptop",
"definition":"(sust. m.) laptop",
"term_audio":"http://wowzahttp.cengage.com/nelson-videos/hed/spanish/audio/laptop.mp3",
"definition_audio":"",
"term_audio_transcript":"Card 132 Term Audio transcript goes here...",
"definition_audio_transcript":""
},


]
